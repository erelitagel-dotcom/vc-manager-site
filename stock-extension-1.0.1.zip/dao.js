
const dao = {
  getHoldings() {
    return JSON.parse(localStorage.getItem("holdings") || "{}");
  },

  saveHoldings(holdings) {
    localStorage.setItem("holdings", JSON.stringify(holdings));
  },

  add(symbol, amount) {
    if (!symbol || amount <= 0) throw new Error("Invalid input.");
    const holdings = this.getHoldings();
    holdings[symbol] = (holdings[symbol] || 0) + amount;
    this.saveHoldings(holdings);
  },

  remove(symbol, amount) {
    if (!symbol || amount <= 0) throw new Error("Invalid input.");
    const holdings = this.getHoldings();
    if (!holdings[symbol] || holdings[symbol] < amount) {
      throw new Error("Not enough balance.");
    }
    holdings[symbol] -= amount;
    if (holdings[symbol] === 0) {
      delete holdings[symbol];
    }
    this.saveHoldings(holdings);
  },

  total() {
    return this.getHoldings();
  },

  async totalValueIn(currency) {
    const holdings = this.total();
    return await service.calculateTotalValue(holdings, currency);
  },

  getCoinGeckoId(symbol) {
    const SYMBOL_MAP = {
      'BTC': 'bitcoin',
      'ETH': 'ethereum',
      'BNB': 'binancecoin',
      'LTC': 'litecoin',
      'XRP': 'ripple',
      'DOGE': 'dogecoin'
    };
    return SYMBOL_MAP[symbol.toUpperCase()] || symbol.toLowerCase();
  },

  clear() {
    localStorage.removeItem("holdings");
  }
};
