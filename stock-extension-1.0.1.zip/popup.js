console.log("✅ popup.js loaded");

let lastSymbolUsed = null;
let pieChartInstance = null;

/* ---------- Helpers: sanitize & getters ---------- */
function cleanAlphaNum(s) {
  return String(s || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^0-9A-Za-z]/g, "")
      .trim();
}
function getSymbolInput() {
  return cleanAlphaNum(document.getElementById("symbol").value).toUpperCase();
}
function getFiatInput() {
  // שומר שלוש אותיות, לדוגמה: USD / ILS / EUR
  return cleanAlphaNum(document.getElementById("targetCurrency").value)
      .toUpperCase()
      .slice(0, 3);
}

function validateInputs() {
  const symbol = getSymbolInput();
  const amount = parseFloat(document.getElementById("amount").value);
  if (!symbol || isNaN(amount) || amount <= 0) {
    throw new Error("Please enter a valid symbol and amount.");
  }
  return { symbol, amount };
}

function resetForm() {
  document.getElementById("symbol").value = "";
  document.getElementById("amount").value = "";
}

function showAlert(msg) {
  const totalOutput = document.getElementById("totalOutput");
  totalOutput.textContent = msg;
  totalOutput.classList.remove("d-none");
  setTimeout(() => totalOutput.classList.add("d-none"), 4000);
}
// עטיפות קצרות לשימוש פנימי
function showError(msg) { showAlert(msg); }
function showInfo(msg)  { showAlert(msg); }

/* ---------- DOM Ready ---------- */
document.addEventListener("DOMContentLoaded", async () => {
  const targetCurrency = document.getElementById("targetCurrency");


  async function loadPieChart() {
    const ctx = document.getElementById('pieChart').getContext('2d');
    const holdings = dao.total();
    const labels = Object.keys(holdings);

    if (labels.length === 0) {
      console.log("אין נתונים להצגה בגרף.");
      return;
    }

    const values = [];

    for (const symbol of labels) {
      const id = dao.getCoinGeckoId(symbol);
      try {
        const rate = await service.getRate(id, 'usd');
        values.push(holdings[symbol] * rate);
      } catch (error) {
        console.error(`שגיאה בטעינת שער עבור ${symbol}:`, error);
        values.push(0); // כדי לשמור את סדר המטבעות
      }
    }

    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          label: 'שווי כולל ב-USD',
          data: values
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom' }
        }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", loadPieChart);



  // ציור התחלתי של הפאי לפי המטבע הנבחר
  try {
    await drawPieChart(dao.total(), getFiatInput().toLowerCase());
  } catch (e) {
    console.warn("initial pie draw failed:", e);
  }

  // רענון הפאי כשמשנים מטבע יעד
  targetCurrency?.addEventListener("change", async () => {
    try {
      await drawPieChart(dao.total(), getFiatInput().toLowerCase());
    } catch (e) {
      console.warn("pie redraw failed:", e);
    }
  });

  document.getElementById("addBtn").addEventListener("click", async () => {
    try {
      const { symbol, amount } = validateInputs();
      dao.add(symbol, amount);
      showAlert(`${amount} ${symbol} added`);
      await drawPieChart(dao.total(), getFiatInput().toLowerCase());
      resetForm();
    } catch (e) {
      showAlert(e.message);
    }
  });

  document.getElementById("removeBtn").addEventListener("click", async () => {
    try {
      const { symbol, amount } = validateInputs();
      dao.remove(symbol, amount);
      showAlert(`${amount} ${symbol} removed`);
      await drawPieChart(dao.total(), getFiatInput().toLowerCase());
      resetForm();
    } catch (e) {
      showAlert(e.message);
    }
  });

  document.getElementById("totalBtn").addEventListener("click", async () => {
    try {
      const holdings = dao.total();
      const currency = getFiatInput(); // USD/ILS/EUR
      const total = await service.calculateTotalValue(holdings, currency);
      showAlert(`Total: ${total.toFixed(2)} ${currency}`);
    } catch (e) {
      showAlert(e.message);
    }
  });

  document.getElementById("resetBtn").addEventListener("click", async () => {
    dao.clear();
    await drawPieChart({}, getFiatInput().toLowerCase());
    showAlert("Portfolio reset.");
  });

  // ----- Show Price History (Handler יחיד) -----
  document.getElementById("historyBtn")?.addEventListener("click", onShowHistory);
});

/* ---------- History handler (uses service.getHistory) ---------- */
async function onShowHistory() {
  const btn  = document.getElementById("historyBtn");
  const sym  = getSymbolInput();  // ETH, BTC...
  const fiat = getFiatInput();    // USD / ILS / EUR

  if (!sym) { showError("Please enter a currency symbol to view history."); return; }

  try {
    if (btn) btn.disabled = true;

    // service.js מחזיר [{date: Date, price: number, t: number}, ...]
    const series = await service.getHistory(sym, fiat, 30);

    if (!Array.isArray(series) || !series.length) {
      throw new Error("No history data available.");
    }

    // drawHistoryChart שלך מקבל [timestamp, price] ותגית מטבע
    const priceData = series.map(p => [
      (p.t ?? (p.date instanceof Date ? p.date.getTime() : p.date)),
      Number(p.price)
    ]);

    drawHistoryChart(priceData, fiat); // מצייר על אותו קנבס של הפאי (כמו אצלך)
    showInfo(""); // ניקוי הודעות קודמות אם יש
  } catch (e) {
    showError(e?.message || "Failed to load history");
  } finally {
    if (btn) btn.disabled = false; // הכפתור תמיד חוזר לפעיל
  }
}

/* ---------- Pie Chart ---------- */
async function drawPieChart(holdings, currency = "usd") {
  const canvas = document.getElementById("pieChart");
  const ctx = canvas.getContext("2d");

  if (pieChartInstance) {
    pieChartInstance.destroy();
  }

  const labels = [];
  const values = [];
  const backgroundColors = [];

  for (const [symbol, amount] of Object.entries(holdings)) {
    try {
      // שולח ל-service.js; הוא כבר מנרמל (CEX=UPPER / CG=lower)
      const rate = await service.getAverageRate(symbol.toLowerCase(), currency.toLowerCase());
      const value = (Number(amount) || 0) * Number(rate || 0);
      labels.push(`${symbol} (${currency.toUpperCase()})`);
      values.push(value);
      backgroundColors.push(`#${Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0')}`);
    } catch (err) {
      console.error(`❌ Failed to fetch rate for ${symbol}: ${err.message}`);
    }
  }

  pieChartInstance = new Chart(ctx, {
    type: "pie",
    data: {
      labels: labels,
      datasets: [{
        data: values,
        backgroundColor: backgroundColors
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { font: { size: 12 } }
        }
      }
    }
  });
}

/* ---------- Line Chart (history) ---------- */
function drawHistoryChart(priceData, currencyLabel = "USD") {
  const canvas = document.getElementById("pieChart"); // מצייר על אותו קנבס
  const ctx = canvas.getContext("2d");

  if (pieChartInstance) {
    pieChartInstance.destroy();
  }

  const labels = priceData.map(p => {
    const date = new Date(p[0]);
    return `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:00`;
  });

  const values = priceData.map(p => p[1]);

  pieChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: `Price (${currencyLabel})`,
        data: values,
        fill: false,
        borderColor: 'blue',
        tension: 0.2
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: true, position: 'top' } },
      scales: {
        x: { ticks: { maxTicksLimit: 7 } },
        y: { beginAtZero: false }
      }
    }
  });
}

/* ---------- חשוב: אין כאן overrides ל-service.* ----------
   אל תגדירי מחדש service.getAverageRate / calculateTotalValue / getRate
   בתוך popup.js. הן מגיעות מ-service.js שכבר עדכנו.
*/
