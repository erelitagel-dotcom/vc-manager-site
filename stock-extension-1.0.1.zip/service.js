// ===== service.js =====

// ---- helpers: sanitize ----
function cleanAlphaNum(s) {
  return String(s || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^0-9A-Za-z]/g, "")
      .trim();
}
function normSymbol(s)     { return cleanAlphaNum(s).toUpperCase(); }      // BTC
function normFiatForCEX(s) { return cleanAlphaNum(s).toUpperCase().slice(0,3); } // USD
function normFiatForCG(s)  { return cleanAlphaNum(s).toLowerCase().slice(0,3); } // usd

// ---- CoinGecko id map ----
const CG_MAP = {
  BTC: "bitcoin",
  ETH: "ethereum",
  BNB: "binancecoin",
  LTC: "litecoin",
  XRP: "ripple",
  DOGE: "dogecoin",
  ADA: "cardano",
  USDT: "tether",
  SOL: "solana",
};
function cgId(symbol) {
  const s = normSymbol(symbol);
  return CG_MAP[s] || s.toLowerCase();
}

// ---- simple in-memory caches (to reduce API calls) ----
const _priceCache   = new Map(); // key: FROM:TO  -> {v, t}
const _historyCache = new Map(); // key: ID:VS:DAYS -> {v, t}
const PRICE_TTL_MS   = 60 * 1000;     // 1 דקה
const HISTORY_TTL_MS = 5 * 60 * 1000; // 5 דקות

function _getCache(map, key, ttl) {
  const hit = map.get(key);
  if (!hit) return null;
  if (Date.now() - hit.t > ttl) { map.delete(key); return null; }
  return hit.v;
}
function _setCache(map, key, v) {
  map.set(key, { v, t: Date.now() });
}

// ---- fetch with retry/backoff on 429/5xx ----
function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

async function jfetch(url, { retries = 2, baseBackoff = 600 } = {}) {
  const base = url.split("?")[0];
  for (let attempt = 0; ; attempt++) {
    const res = await fetch(url, { headers: { accept: "application/json" } });
    if (res.status === 429 || res.status >= 500) {
      if (attempt < retries) {
        const jitter = Math.floor(Math.random() * 250);
        await sleep(baseBackoff * Math.pow(2, attempt) + jitter);
        continue;
      }
      throw new Error(`HTTP ${res.status} ${base}`);
    }
    if (!res.ok) throw new Error(`HTTP ${res.status} ${base}`);
    return res.json();
  }
}

// ---- sources ----
async function getFromCEX(from, to) {
  const key = `CEX:${from}:${to}`;
  const cached = _getCache(_priceCache, key, PRICE_TTL_MS);
  if (cached != null) return cached;

  const url = `https://cex.io/api/last_price/${normSymbol(from)}/${normFiatForCEX(to)}`;
  const j = await jfetch(url);
  const p = Number(j?.lprice);
  if (!Number.isFinite(p)) throw new Error("CEX returned bad price");
  _setCache(_priceCache, key, p);
  return p;
}

async function getFromCG(from, to) {
  const id = cgId(from);
  const vs = normFiatForCG(to);
  const key = `CG:${id}:${vs}`;
  const cached = _getCache(_priceCache, key, PRICE_TTL_MS);
  if (cached != null) return cached;

  const url = `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(id)}&vs_currencies=${encodeURIComponent(vs)}`;
  const j = await jfetch(url, { retries: 2, baseBackoff: 700 });
  const p = Number(j?.[id]?.[vs]);
  if (!Number.isFinite(p)) throw new Error("CoinGecko returned bad price");
  _setCache(_priceCache, key, p);
  return p;
}

const service = {
  // ---- average from two sources with fallback ----
  async getAverageRate(from, to) {
    const FROM = normSymbol(from);
    const TO   = normFiatForCEX(to);
    const TOvs = normFiatForCG(to);
    if (!FROM || !TO || !TOvs) throw new Error(`Invalid symbol or currency: ${FROM}/${TO || to}`);

    // use cache first
    const cacheKey = `AVG:${FROM}:${TO}`;
    const cached = _getCache(_priceCache, cacheKey, PRICE_TTL_MS);
    if (cached != null) return cached;

    const [cex, cg] = await Promise.allSettled([ getFromCEX(FROM, TO), getFromCG(FROM, TOvs) ]);
    const ok = [cex, cg].filter(r => r.status === "fulfilled").map(r => r.value);
    if (!ok.length) throw new Error(`Failed to fetch rate for ${FROM}/${TO}`);
    const avg = ok.reduce((a,b)=>a+b,0) / ok.length;
    _setCache(_priceCache, cacheKey, avg);
    return avg;
  },

  async calculateTotalValue(holdings, currency) {
    let total = 0;
    if (!holdings) return 0;
    for (const [symbol, amount] of Object.entries(holdings)) {
      const rate = await this.getAverageRate(symbol, currency);
      total += (Number(amount) || 0) * rate;
    }
    return total;
  },

  // ---- market history (default 30 days) ----
  async getHistory(symbol, currency, days = 30) {
    const id = cgId(symbol);
    const vs = normFiatForCG(currency);
    const key = `HIST:${id}:${vs}:${days}`;
    const cached = _getCache(_historyCache, key, HISTORY_TTL_MS);
    if (cached) return cached;

    const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart?vs_currency=${encodeURIComponent(vs)}&days=${encodeURIComponent(days)}`;
    const data = await jfetch(url, { retries: 2, baseBackoff: 900 }); // ידידותי ל-429
    const rows = (data?.prices || []).map(([ts, price]) => ({
      t: ts,
      date: new Date(ts),
      price: Number(price)
    }));
    if (!rows.length) throw new Error("No history data available.");
    _setCache(_historyCache, key, rows);
    return rows;
  },

  // ---- 7-day range: same format ----
  async getPriceHistory(symbol, target) {
    const end = Math.floor(Date.now() / 1000);
    const start = end - 7 * 24 * 60 * 60;
    const id = cgId(symbol);
    const vs = normFiatForCG(target);
    const key = `HISTRANGE:${id}:${vs}:${start}:${end}`;
    const cached = _getCache(_historyCache, key, HISTORY_TTL_MS);
    if (cached) return cached;

    const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart/range?vs_currency=${encodeURIComponent(vs)}&from=${start}&to=${end}`;
    const json = await jfetch(url, { retries: 2, baseBackoff: 900 });
    const rows = (json?.prices || []).map(([ts, price]) => ({
      t: ts,
      date: new Date(ts),
      price: Number(price)
    }));
    if (!rows.length) throw new Error("No history data available.");
    _setCache(_historyCache, key, rows);
    return rows;
  },

  async getRate(from, to) {
    return this.getAverageRate(from, to);
  }
};

// expose (MV3)
window.service = service;
